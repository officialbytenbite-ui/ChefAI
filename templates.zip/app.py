# app.py
import os
from flask import Flask, request, jsonify, render_template
from flask_cors import CORS
from dotenv import load_dotenv
from google import genai

# Load .env
load_dotenv()
client = genai.Client(api_key=os.getenv("GEMINI_API_KEY"))

# # Get Gemini API key
# API_KEY = os.getenv("GEMINI_API_KEY")
# if not API_KEY:
#     raise ValueError("GEMINI_API_KEY not found in .env")

# Initialize Gemini client
# client = genai.Client(api_key=API_KEY)

# Initialize Flask
app = Flask(__name__)
CORS(app)  # Allow API calls from frontend

# Serve the HTML page
@app.route("/")
def home():
    return render_template("home.html")  # put your HTML file in templates/index.html

@app.route("/chatbot")
def chatbot():
    return render_template("chatbot.html")  # put your HTML file in templates/index.html

# API endpoint for generating recipes
@app.route("/generate-recipe", methods=["POST"])
def generate_recipe():
    data = request.json
    ingredients = data.get("ingredients")
    health = data.get("health")
    cuisine = data.get("cuisine")

    if not ingredients:
        return jsonify({"recipe": "Please provide ingredients!"})
    
    print(f'HI --- {os.getenv("GEMINI_API_KEY")}')
    prompt = f"""
    Create a detailed {cuisine} recipe using the following ingredients: {ingredients}.
    Health preference: {health}.
    Provide step-by-step instructions with quantities for each ingredient.
    """

    try:
        response = client.models.generate_content(
            model="gemini-2.0-flash",
            contents=prompt
        )
        return jsonify({"recipe": response})
        # Use chat-bison-001 via chat() method
        # response = client.chat(
        #     model="chat-bison-001",
        #     messages=[{"author": "user", "content": prompt}],
        #     temperature=0.7,
        #     max_output_tokens=800
        # )

        # recipe_text = response.last.content
        # return jsonify({"recipe": recipe_text})

    except Exception as e:
        print("Error generating recipe:", e)
        return jsonify({"recipe": "Error generating recipe. Try again!"})

if __name__ == "__main__":
    # Run on port 5000, accessible via localhost
    app.run(debug=True)
