import os
from dotenv import load_dotenv
import google.genai as genai

load_dotenv()
api_key = os.getenv("GEMINI_API_KEY")
client = genai.Client(api_key=api_key)

response = client.generate_text(
    model="text-bison-001",
    prompt="Write a simple Indian recipe with rice and tomato",
    temperature=0.7,
    max_output_tokens=200
)

print(response.text)
